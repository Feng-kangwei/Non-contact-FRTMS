#ifndef   __Timer_H
#define   __Timer_H
#include "stm32f10x.h"
#include "sys.h"

//void TIM3_Int_Init(u16 arr,u16 psc);

#endif
