V1.1 软件使用说明:
1.双击打开DataAssistant.exe
2.按照软件上的使用说明进行操作
3.禁止修改config.ini文件
4.如遇软件无法打开运行，请检查软件根目录下，是否包含必要文件:
1.sipeed.ico;2.config.ini.
5.VoTT下载地址:
https://github.com/microsoft/VoTT/releases/tag/v2.1.0
6.VoTT帮助文档:
https://github.com/Microsoft/VoTT/blob/master/README.md
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
V1.1 Software instructions:
1.Double-click to open DataAssistant.exe
2. Follow the instructions on the software
3. Prohibit modification of config.ini file
4. If the software fails to open and run, 
please check whether the software root directory contains the necessary files: 1.sipeed.ico; 2.config.ini.
5.Vott download link:
https://github.com/microsoft/VoTT/releases/tag/v2.1.0
6.VoTT Help documentation:
https://github.com/Microsoft/VoTT/blob/master/README.md

